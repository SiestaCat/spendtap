// === Lógica botón guardar ===

// Initialize save button (now handled by home-save-modal.js)
function initSaveButton() {
  // El botón guardar ahora es manejado por home-save-modal.js
  // Este archivo se mantiene para compatibilidad pero no hace nada
}

// Export functions
window.initSaveButton = initSaveButton;